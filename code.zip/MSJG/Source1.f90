        Program routing

        implicit none
! this program routes the daily surface runoff and base flow that are calculated
! by vic from each grid cells to the watershed outlet through the lineal 
! reservior and muskingum methods.
        
        integer, parameter:: ngrid=732 ! Number of grid cells within the watershed
        real, parameter:: dt=24 ! Time step of model simulation
        integer, parameter:: startyear=2003 ! Year starting the routing
        integer, parameter:: endyear=2012 ! Year ending the routing
	integer, parameter:: num_mon=120 !monthly observations
        character(72), parameter:: gridinfo_dir='../PARAMETER/info.txt' ! Directory of grid information file
        character(72), parameter:: output_daily_dir='../results/routing_results_day.txt' ! Directory of output daily streamflow file
        character(72), parameter:: output_monthly_dir='../results/routing_results_month.txt' ! Directory of output daily streamflow file
        character(72), parameter:: flux_dir='../Qs_focing/fluxes_' ! Directory of flux files
        character(72), parameter:: qobs_dir='../PARAMETER/Q.txt' ! Directory of observed streamflow data file                
	character(72), parameter:: CXbs_dir='../PARAMETER/Q.txt' ! Directory of observed streamflow data file                
	real,parameter:: sm=50   !!SM(10-200)
        real,parameter:: ki=0.5
        real,parameter:: kg=0.5
        real,parameter:: cs=0.5  !0.01-0.99
        real,parameter:: ci=0.9
        real,parameter:: cg=0.9
        real,parameter:: v=4
        real,parameter:: kmus=48  !0.00-100
        real,parameter:: xmus=0.4  !0.01-0.5
       
       
        real, parameter:: qrs00=0. ! Initial surface discharge at each grid cell
        real, parameter:: qri00=0. ! Initial interflow discharge at each grid cell
        real, parameter:: qrg00=0.7 ! Initial groundwater discharge at each grid cell
        real, parameter:: s0=0. ! Initial free water storage at each grid cell

        integer:: nt ! Total number of time steps for model simulation

        real:: s
        real:: qrs0
        real:: qrg0
        real:: qri0      
        integer:: nmus
        real:: area
        real:: lat
        real:: lon
        real:: riverlen
        real:: qgrid(50000)
        real:: p
        real:: e
        real:: rs
        real:: rg
        real:: rss
        real:: rgg
        real:: rii
        real:: qrs
        real:: qrg
        real:: qri
        real:: qi(50000)
        real:: qj(50000)
        real:: qo(50000)
        real:: qc(50000)
        real:: pmean(50000)
        real:: emean(50000)
        real:: r1mean(50000)
        real:: r2mean(50000)
        real:: qobs(50000)

        real:: pmonth(50000) ! Monthly precipitation
        real:: emonth(50000) ! Monthly evaporation
        real:: rmonth(50000) ! Monthly runoff depth
        real:: qobsmonth(50000) ! Monthly observed streamflow
        real:: qcalmonth(50000) ! Monthly calculated streamflow
        real:: nash_day ! Nash model efficiency coefficient for daily streamflow simulation
        real:: nash_month ! Nash model efficiency coefficient for monthly streamflow simulation
        real:: bias ! Relative runoff error  
        
        integer:: i
        integer:: j
        integer:: k
        character:: chrtemp
        real:: temp
        real:: gridid
        integer:: year(50000)
        integer:: month(50000)
        integer:: day(50000)
        real:: u
	
        character *72 filename
        integer nmyfile
	real*8 rrr(50000),cc(50000),dd(50000),ee(50000),ff(50000),gg(50000)
	integer aa(50000),bb(50000)

        write (*,'(8F10.4)')sm,ki,kg,cs,ci,cg,kmus,xmus 

        ! Calculate the total number of time steps for routing
       
        nt=0
        do i=startyear, endyear    !�ж����������������
          if (mod(i,4).eq.0.and.mod(i,100).ne.0 &
              .or. mod(i,100).eq.0.and.mod(i,400).eq.0) then
            nt=nt+366
          else
            nt=nt+365
          end if
        end do

	open (unit=111,file=CXbs_dir,action='read')
        open (unit=1,file=gridinfo_dir, status='old')
        open (unit=2,file=output_daily_dir,action='write') 
        open (unit=5,file=output_monthly_dir,action='write') 
        open (unit=4,file=qobs_dir,action='read')
	do i=1,num_mon
	  read(111,*) rrr(i)
	end do
!----
        do i=1,nt
          read(4,*) qobs(i)
        end do 
        close (4)
            
        do i=1,nt
          qj(i)=0.
          pmean(i)=0.
          emean(i)=0.
          r1mean(i)=0.
          r2mean(i)=0.
        end do

        read(1,*) chrtemp

        do i=1,ngrid
          
          do j=1,nt
            qgrid(j)=0
            qi(j)=0.
            qo(j)=0.
            qc(j)=0.
          end do

          qrs0=qrs00
          qrg0=qrg00
          qri0=qri00
          s=s0
     
          read (1,*) gridid,lat,lon,area,riverlen
          u=area/(dt*3.6)  !���/ʱ��
	  filename=flux_dir 
	  nmyfile=len_trim(filename)
	  write (filename(nmyfile+1:nmyfile+6),'(f6.3)') lat
      	  write (filename(nmyfile+7:nmyfile+7),'(a1)') '_'
	  if (lon.ge.100) then
	  write (filename(nmyfile+8:nmyfile+15),'(f7.3)') lon
	  else
	  write (filename(nmyfile+8:nmyfile+15),'(f6.3)') lon
	  end if
	  !write (*,*) filename

	  open (unit=3, file=filename, status='old')
          nmus=nint(riverlen/3600.0/dt/v)
          if (nmus.le.1) nmus=1

          read (3,*) year(1), month(1), day(1), p, e, &
                  rs, rg, temp, temp, temp, temp, temp, &
                  temp, temp, temp, temp, temp, temp, &
                  temp, temp, temp, temp, temp, temp, &
                  temp, temp, temp
          do while (year(1).lt.startyear)
            read (3,*) year(1), month(1), day(1), p, e, &
                  rs, rg, temp, temp, temp, temp, temp, &
                  temp, temp, temp, temp, temp, temp, &
                  temp, temp, temp, temp, temp, temp, &
                  temp, temp, temp
          end do
          s=s+rs+rg  !�ܾ���=�ر�����+����
            !��ˮԴ
          if (s.gt.sm) then
              rss=0
              rgg=s*kg
              rii=s*ki
              s=s-rss-rgg-rii 
          else
              rss=0
              rgg=s*kg
              rii=s*ki
              s=s-rss-rgg-rii
          end if            

          qrs=0   ! u=area/(dt*3.6)  !���/ʱ��  ����ˮ��ģ��
          qrg=qrg0*cg+rgg*(1-cg)*u
          qri=qri0*ci+rii*(1-ci)*u
          qgrid(1)=qrs+qrg+qri
          qrs0=qrs
          qrg0=qrg
          qri0=qri

          r1mean(1)=r1mean(1)+rs/real(ngrid)
          r2mean(1)=r2mean(1)+rg/real(ngrid)
          pmean(1)=pmean(1)+p/real(ngrid)
          emean(1)=emean(1)+e/real(ngrid)

          do j=2,nt
! read flux file
          read (3,*) year(j), month(j), day(j), p, e, &
                  rs, rg, temp, temp, temp, temp, temp, &
                  temp, temp, temp, temp, temp, temp, &
                  temp, temp, temp

! routing within grid cells
            s=s+rs+rg
            
            if (s.gt.sm) then
              rss=0
              rgg=s*kg
              rii=s*ki
              s=s-rss-rgg-rii
            else
              rss=0
              rgg=s*kg
              rii=s*ki
              s=s-rss-rgg-rii
            end if            

            qrs=0
            qrg=qrg0*cg+rgg*(1-cg)*u
            qri=qri0*ci+rii*(1-ci)*u
            qgrid(j)=qrs+qrg+qri
            qrs0=qrs
            qrg0=qrg
            qri0=qri

            r1mean(j)=r1mean(j)+rs/real(ngrid)
            r2mean(j)=r2mean(j)+rg/real(ngrid)
            pmean(j)=pmean(j)+p/real(ngrid)
            emean(j)=emean(j)+e/real(ngrid)
            
          end do
          close (3)

! river flow routing

          do j=1,nt
            qi(j)=qgrid(j)
          end do
          
          do j=1,nmus
            qc(j)=qi(1)
          end do
             
          call msk(kmus,xmus,nmus,dt,nt,qi,qo,qc)

          do j=1,nt
            qj(j)=qj(j)+qo(j)
          end do
        end do 

        do i=1,nt
          pmonth(i)=0.
          emonth(i)=0.
          rmonth(i)=0.
          qobsmonth(i)=0.
          qcalmonth(i)=0.
        end do

        pmonth(1)=pmean(1)
        emonth(1)=emean(1)
        rmonth(1)=r1mean(1)+r2mean(1)
        qobsmonth(1)=qobs(1)
        qcalmonth(1)=qj(1)
        write (5,'(8a10)') 'Year','Month','Prec','Evap','Runoff','Q_obs','Q_cal'
        j=1
        do i=2,nt
          if (month(i).eq.month(i-1)) then
            pmonth(j)=pmonth(j)+pmean(i)
            emonth(j)=emonth(j)+emean(i)
            rmonth(j)=rmonth(j)+r1mean(i)+r2mean(i)
            qobsmonth(j)=qobsmonth(j)+qobs(i)
            qcalmonth(j)=qcalmonth(j)+qj(i)
          else
            qobsmonth(j)=qobsmonth(j)/real(day(i-1))
            qcalmonth(j)=qcalmonth(j)/real(day(i-1))
            write (5,'(2i10,5f10.3)')year(i-1),month(i-1),&
                  pmonth(j),emonth(j),rmonth(j),qobsmonth(j),qcalmonth(j) 
            j=j+1
            pmonth(j)=pmonth(j)+pmean(i)
            emonth(j)=emonth(j)+emean(i)
            rmonth(j)=rmonth(j)+r1mean(i)+r2mean(i)
            qobsmonth(j)=qobsmonth(j)+qobs(i)
            qcalmonth(j)=qcalmonth(j)+qj(i)            
          end if
          if (i.eq.nt) then
            qobsmonth(j)=qobsmonth(j)/real(day(i))
            qcalmonth(j)=qcalmonth(j)/real(day(i))
          end if
          
        end do

        write (5,'(2i10,5f10.3)')year(i-1),month(i-1),&
              pmonth(j),emonth(j),rmonth(j),qobsmonth(j),qcalmonth(j)   !!!!��ģ��ֵ

        write (2,'(8a10)') 'Year','Month','Day','Prec','Evap','Runoff','Q_obs','Q_cal'
        do i=1,nt
          write (2,'(3i10,5f10.3)')year(i),month(i),&
           day(i), pmean(i),emean(i),r1mean(i)+r2mean(i),qobs(i), &
           qj(i)
        end do 

        close (1)
        close (2)
        close (5)
!===
        open (unit=5,file=output_monthly_dir,action='read') 
	read(5,*)
	do i=1,num_mon
	  read(5,"(2i10,5f10.3)") aa(i),bb(i),cc(i),dd(i),ee(i),ff(i),gg(i)
	end do
	close(5)
	ff(:)=rrr(:)
	open(unit=112,file='out.txt')
	write (112,'(8a10)') 'Year','Month','Prec','Evap','Runoff','Q_obs','Q_cal'
	do i=1,num_mon
	  write(112,'(2i10,5f10.3)') aa(i),bb(i),cc(i),dd(i),ee(i),ff(i),gg(i)
	end do
	close(112)
!===
	!----
	qobsmonth(:)=rrr(:)

        ! Calculate Nash and Bias for daily streamflow simulation
        call nash_bias(nt,qobs,qj,nash_day,bias)

        ! Calculate Nash and Bias for monthly streamflow simulation
        call nash_bias(j,qobsmonth,qcalmonth,nash_month,bias)
      write (*,'(a110,F10.3)') 'Nash-Sutcliffe model efficiency coefficient for daily streamflow simulation:  ', Nash_day
      write (*,'(a110,F10.3)') 'Nash-Sutcliffe model efficiency coefficient for monthly streamflow simulation:  ', Nash_month
      write (*,'(a110,F10.3)') 'Relative error between Qcal and Qobs:  ', bias         


        end program 
        
        subroutine msk(k,x,n,dt,nt,qi,qo,qc)
        implicit none
       
        real k
        real x
        real dt
 
        integer n
        integer nt
        
        real qi(50000)
        real qo(50000)
        real qc(50000)
        real qo1
        real qo2
        real qi1
        real qi2

        real x1
        real c0
        real c1
        real c2
 
        integer i
        integer j

        x1=k-k*x+0.5*dt
        c0=(0.5*dt-k*x)/x1
        c1=(k*x+0.5*dt)/x1
        c2=(k-k*x-0.5*dt)/x1
     
        do  i=1,n
          if (qc(i).le.0.0) qc(i)=qi(1)
        end do
 
        if (qo(1).le.0.0) qo(1)=qc(n)

        do  i=2,nt
          do j=1,n
            qo1=qc(j)
            if (j.eq.1) then
              qi1=qi(i-1)
              qi2=qi(i)
            end if
            qo2=c0*qi2+c1*qi1+c2*qo1
            qi1=qo1
            qi2=qo2
            qc(j)=qo2
          end do
          qo(i)=qo2
        end do
        return
        end subroutine

        subroutine nash_bias (nstep, qobs,qcal,nash,bias)
        implicit none
        
        integer:: nstep
        real:: qobs(50000)
        real:: qcal(50000)
        real:: nash
        real:: bias
      
        integer:: i
        real:: s_qobs
        real:: s_qcal
        real:: qobs_mean
        real:: qcal_mean
        real:: s1
        real:: s2

        s_qobs=0.
        s_qcal=0.
        s1=0.
        s2=0.

        do i=1,nstep
          s_qobs=s_qobs+qobs(i)
          s_qcal=s_qcal+qcal(i)
        end do

        qobs_mean=s_qobs/real(nstep)
       
        
        do i=1,nstep
          s1=s1+(qobs(i)-qcal(i))**2
          s2=s2+(qobs(i)-qobs_mean)**2
        end do      

        bias=(s_qcal-s_qobs)/abs(s_qobs)
        nash=1-s1/s2

        return
        
        end subroutine

