        !COMPILER-GENERATED INTERFACE MODULE: Wed Nov 16 16:14:02 2022
        MODULE NASH_BIAS__genmod
          INTERFACE 
            SUBROUTINE NASH_BIAS(NSTEP,QOBS,QCAL,NASH,BIAS)
              INTEGER(KIND=4) :: NSTEP
              REAL(KIND=4) :: QOBS(50000)
              REAL(KIND=4) :: QCAL(50000)
              REAL(KIND=4) :: NASH
              REAL(KIND=4) :: BIAS
            END SUBROUTINE NASH_BIAS
          END INTERFACE 
        END MODULE NASH_BIAS__genmod
