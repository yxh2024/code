        !COMPILER-GENERATED INTERFACE MODULE: Wed Nov 16 16:14:02 2022
        MODULE MSK__genmod
          INTERFACE 
            SUBROUTINE MSK(K,X,N,DT,NT,QI,QO,QC)
              REAL(KIND=4) :: K
              REAL(KIND=4) :: X
              INTEGER(KIND=4) :: N
              REAL(KIND=4) :: DT
              INTEGER(KIND=4) :: NT
              REAL(KIND=4) :: QI(50000)
              REAL(KIND=4) :: QO(50000)
              REAL(KIND=4) :: QC(50000)
            END SUBROUTINE MSK
          END INTERFACE 
        END MODULE MSK__genmod
