!====
    
!identify VIC_BP surrogate model parameter 

Module Model_data
implicit none
integer, parameter :: d = 3!  !!rly
integer, parameter :: nb = 3
!nb nothing
!--
End Module
!====
! Module used for piror information
!--

Module Model_data2
implicit none
integer, parameter :: d1=3   !!!rly
integer, parameter :: col=2
real*8 ranges (d1, col)
!--
!data ranges(1, 1:2) /-5.12, 5.12/
!data ranges(2, 1:2) /-5.12, 5.12/
data ranges(1, 1:2) /0.01d0, 0.3d0/  !!!ki
data ranges(2, 1:2) /0.01d0, 0.6d0/   !!!ci
data ranges(3, 1:2) /0.01d0, 0.3d0/       !!!cg
!data ranges(4, 1:2) /10d0, 10d0/   !!!kmus
!data ranges(5, 1:2) /0.01d0, 0.4d0/   !!!xmus

End Module
!====
! Module for Head observations
Module Model_data3
implicit none
integer, parameter :: n_obs=120
real*8 obs(n_obs)

contains

subroutine read_ob()
  implicit none
  integer::i
  open(170,file='obs.txt')
    do i=1,n_obs,1
      read(170,*) obs(i)
    end do
  close(170)
end subroutine
  
End Module
!--

!====
!--Parameter description for the DREAMzs module
!-----------------------------------------------------------------------------------------------
!--d, dimension of parameter set
!--n, number of initial Markov Chains (parallel chain)
!--limit, the maximum length of burn-in period
!--nrc, user defined parameter for deriving CR probability distribution
!--num, number of iternations after burn-in period
!--sig, number of chain pairs used for sample generation
!--b1,b2, are the b and b* in equation 4, Ud(-b,b), Nd(0,b*)
!    the use of b2 is different from Vrugt at here
!--st, the start time to test convergence
!--ilen is the initial length of burn_in chain, for obtaining initial points and archive Z
!--CRUpdate is the start time to update CR distribution
!--SR, the convergence criterion.
!--M0, the length of arichive matrix Z[M0, d]
!--TK, thinning rate
!--Psk, the percentage of snooker update, which must has less than or equal 2 decimals.
!--Out_step the step size of output
!--Status = 0 for ending of burn-in, 1 for after burn-in, -1 for before burn-in
!----------------------------------------------------------------------------------
Module Model_data4
implicit none
!----
integer, parameter :: d3=3
integer, parameter :: n=3 !
integer, parameter :: limit=500  !!!rly ����
integer, parameter :: num=500
Integer, parameter :: Out_step = num/20
!----
integer, parameter :: ncr=3
integer, parameter :: sig=1
integer, parameter :: st=limit/2
integer, parameter :: M0=8*d3
integer, parameter :: TK=10
integer, parameter :: CRUpdate=limit/10
integer, parameter :: ilen=M0/n+1
!--
real*8, parameter :: b1=0.05
real*8, parameter :: b2=0.000001
real*8, parameter :: SR=1.2
real*8, parameter :: Psk=0.1D+00
!--
End Module
!====
!=============================================================
Program main
Use Model_data
Use Model_data4
!--
implicit none
Integer Status
logical alive
!--
inquire (file = 'Status.txt', exist = alive)
!!!!!!delete "status.txt" every time
if (alive) then
!--
  open (unit=101, file='Status.txt', recl=50, blank='null', position='rewind', pad='yes')
  read (unit=101, fmt='(i1)') Status
  close (101)
!--
else
  Status = -1
end if
!--
if (Status == -1) then
  Call DREAM_1(d, nb, ncr, n, sig, limit, st, ilen, CRUpdate, b1, b2, SR, M0, TK, Psk)
  Call DREAM_2(d, nb, ncr, n, sig, limit, num, b1, b2, M0, TK, Psk, Out_step, ilen)
else if (Status == 1 .or. Status == 0) then
  Call DREAM_2(d, nb, ncr, n, sig, limit, num, b1, b2, M0, TK, Psk, Out_step, ilen)
end if
!--
Stop
End Program